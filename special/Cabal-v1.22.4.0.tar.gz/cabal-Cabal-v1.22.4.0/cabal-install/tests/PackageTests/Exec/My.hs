module Main where

main :: IO ()
main = do
    putStrLn "This is my-executable"
