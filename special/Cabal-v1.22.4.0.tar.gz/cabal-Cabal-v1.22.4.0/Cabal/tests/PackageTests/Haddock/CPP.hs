{-# LANGUAGE CPP #-}

module CPP where

#define HIDING  hiding
#define NEEDLES needles

-- | For HIDING NEEDLES.
data Haystack = Haystack
