module Main where

import Foo

main :: IO ()
main = return ()
