module Dummy where

import Distribution.TestSuite (Test)

tests :: IO [Test]
tests = return []
