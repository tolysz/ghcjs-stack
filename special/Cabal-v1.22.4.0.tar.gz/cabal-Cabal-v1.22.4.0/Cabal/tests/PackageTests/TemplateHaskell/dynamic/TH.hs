{-# LANGUAGE TemplateHaskell #-}
module TH where

splice = [| () |]
