import System.Time
import MyLibrary

main = do
    getClockTime
    myLibFunc
