module Foo where

fooTest :: [String] -> Bool
fooTest _ = True
